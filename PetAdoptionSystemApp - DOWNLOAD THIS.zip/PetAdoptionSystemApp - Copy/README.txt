1. Install Java JDK 17 or higher.
2. Install MySQL Server 8.0.
3. Open MySQL Workbench or command line and import 'pet_adoption_system.sql' to create the database.
4. Ensure MySQL server is running and matches your database connection settings.
5. Double-click 'PetAdoptionSystem.jar' or run it via command line:
   > java -jar PetAdoptionSystem.jar
6. Make sure the 'lib/mysql-connector-j-9.2.0.jar' is in the same folder or classpath.


- Kailangan may MYSQL Server 8.0 yung PC or Laptop mo
- Kailangan din may JDK 17 or mas mataas
- Kailangan mo muna iimport yung database na pet_adoption_system.sql 
  sa command line or MySQL Workbench kung meron ka non
-		